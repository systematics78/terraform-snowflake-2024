import json
import sys

def read_json(file_path):
    with open(file_path, 'r') as file:
        return json.load(file)

def transform_data(data):
    result = {"databases": {}}
    for item in data:
        db_name = item["db_name"]
        schema_name = item["schema_name"]
        
        if db_name not in result["databases"]:
            result["databases"][db_name] = {
                "central_schemas": False,
                "extensions": True,
                "db_name": db_name,
                "db_comment": item.get("db_comment", ""),
                "db_retention_days": item.get("db_retention_days", 0),
                "db_transient": item.get("transient", False),
                "local_schemas": {},
                "tags": {}
            }
        
        db = result["databases"][db_name]
        
        db["local_schemas"][schema_name] = {
            "schema_name": schema_name,
            "schema_comment": item.get("schema_comment", ""),
            "schema_retention_days": item.get("schema_retention_days", 0),
            "schema_transient": item.get("transient", False),
            "schema_managed": item.get("managed", False),
            "tags": {}
        }
        
        schema_tags = db["local_schemas"][schema_name]["tags"]
        for tag in ["SUB_DOMAIN_OWNER", "DOMAIN_ARCHITECT", "DATA_STEWARD", "EDATA_AUTHOR"]:
            schema_tags[tag] = {
                "value": item.get(tag, "localhost@localhost"),
                "allowed_values": []
            }
        
        for tag in ["ENTERPRISE_DATA_DOMAIN", "DATA_OWNER", "EDO_DELEGATE", "ISRM_BISM_DATA_CLASSIFICATION", "DOMAIN_DATA_GOVERNANCE", "TT_DELIVERY_LEAD", "DATA_ARCHITECT", "DATA_MODELER"]:
            if tag not in db["tags"]:
                db["tags"][tag] = {
                    "value": item.get(tag, "localhost@localhost"),
                    "allowed_values": []
                }
    
    return result

def dict_to_hcl(dictionary, indent=0):
    hcl_output = ""
    indent_str = "  " * indent
    for key, value in dictionary.items():
        if isinstance(value, dict):
            hcl_output += f'{indent_str}{key} = {{\n'
            hcl_output += dict_to_hcl(value, indent + 1)
            hcl_output += f'{indent_str}}}\n'
        elif isinstance(value, list):
            list_items = ', '.join([f'"{item}"' for item in value])
            hcl_output += f'{indent_str}{key} = [{list_items}]\n'
        elif isinstance(value, bool):
            hcl_output += f'{indent_str}{key} = {str(value).lower()}\n'
        else:
            hcl_output += f'{indent_str}{key} = "{value}"\n'
    return hcl_output

def main():
    if len(sys.argv) != 3:
        print("Usage: python script.py <input_file_path> <output_file_path>")
        sys.exit(1)
    
    input_file_path = sys.argv[1]
    output_file_path = sys.argv[2]

    # Reading, transforming, and writing data
    data = read_json(input_file_path)
    transformed_data = transform_data(data)
    hcl_data = dict_to_hcl(transformed_data)

    with open(output_file_path, 'w') as output_file:
        output_file.write(hcl_data)

    print(f'Data has been transformed and written to {output_file_path}')

if __name__ == "__main__":
    main()
