import json
import sys

def combine_json_files(input_file1, input_file2, output_file):
    # Load data from the first JSON file
    with open(input_file1, 'r') as file:
        data1 = json.load(file)

    # Load data from the second JSON file
    with open(input_file2, 'r') as file:
        data2 = json.load(file)

    # Combine data from both files
    combined_data = data1 + data2

    # Save the combined data to the output JSON file
    with open(output_file, 'w') as file:
        json.dump(combined_data, file, indent=4)
    print(f"Data combined successfully into {output_file}")

if __name__ == '__main__':
    if len(sys.argv) != 4:
        print("Usage: python script.py <inputfile1.json> <inputfile2.json> <outputfile.json>")
    else:
        _, input_file1, input_file2, output_file = sys.argv
        combine_json_files(input_file1, input_file2, output_file)
