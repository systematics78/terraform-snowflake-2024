WITH MVTABLEF AS (SELECT M.MATERIALIZED_VIEW, M.START_TIME, M.END_TIME, 
    M.TOTAL_CREDITS_USED, B.UC_NAME, P.OWNER, L.LAYER, REGEXP_SUBSTR(REGEXP_REPLACE(UC_NAME, '_', ' '),'SNO\\W+(\\w+)' , 1 , 1 , 'ie') AS APP_NAME,
    'MATERIALIZED_VIEW_MAINTENANCE - ' || REGEXP_SUBSTR(REGEXP_REPLACE(UC_NAME, '_', ' '),'SNO\\W+(\\w+)' , 1 , 1 , 'ie') AS WH_NAME, 
    APP_ID.COST_CENTER AS APP_ID, C.COST_CENTER, S.SUBJECT_AREA, DESCRI.DESCRIPTION 
    FROM (SELECT TABLE_NAME AS MATERIALIZED_VIEW, START_TIME, END_TIME, CREDITS_USED AS TOTAL_CREDITS_USED
    FROM SNOWFLAKE.ACCOUNT_USAGE.MATERIALIZED_VIEW_REFRESH_HISTORY WHERE START_TIME >= DATEADD('MONTH',-11,CURRENT_TIMESTAMP())) AS M 
    JOIN                                   
    (SELECT DISTINCT TABLE_NAME, TABLE_OWNER AS UC_NAME FROM  SNOWFLAKE.ACCOUNT_USAGE.TABLES 
    WHERE TABLE_TYPE='MATERIALIZED VIEW' AND TABLE_OWNER IS NOT NULL AND DELETED IS NULL) AS B
    ON M.MATERIALIZED_VIEW = B.TABLE_NAME
    LEFT JOIN
    (SELECT DISTINCT TAG_VALUE AS OWNER, OBJECT_NAME AS WH_NAME FROM SNOWFLAKE.ACCOUNT_USAGE.TAG_REFERENCES                   
    WHERE TAG_NAME='OWNER' AND DOMAIN='ROLE' AND OBJECT_DELETED IS NULL) AS P
    ON B.UC_NAME = P.WH_NAME
    LEFT JOIN
    (SELECT 'N/A' SUBJECT_AREA) AS S
    LEFT JOIN
    (SELECT DISTINCT OBJECT_NAME, TAG_VALUE AS COST_CENTER FROM SNOWFLAKE.ACCOUNT_USAGE.TAG_REFERENCES WHERE TAG_NAME='COST_CENTER'AND DOMAIN='ROLE' 
    AND OBJECT_DELETED IS NULL ) AS C
    ON P.WH_NAME = C.OBJECT_NAME
    LEFT JOIN
    (SELECT DISTINCT OBJECT_NAME, TAG_VALUE AS LAYER FROM SNOWFLAKE.ACCOUNT_USAGE.TAG_REFERENCES WHERE TAG_NAME='LAYER'AND DOMAIN='ROLE' 
    AND OBJECT_DELETED IS NULL ) AS L
    ON P.WH_NAME = L.OBJECT_NAME
    LEFT JOIN
    (SELECT DISTINCT OBJECT_NAME, TAG_VALUE AS COST_CENTER FROM SNOWFLAKE.ACCOUNT_USAGE.TAG_REFERENCES WHERE TAG_NAME='COST_CENTER'AND DOMAIN='ROLE' 
    AND OBJECT_DELETED IS NULL ) AS APP_ID
    ON P.WH_NAME = APP_ID.OBJECT_NAME
    LEFT JOIN
    (SELECT 'IN ORDER TO PREVENT MATERIALIZED VIEWS FROM BECOMING OUT-OF-DATE, SNOWFLAKE PERFORMS AUTOMATIC BACKGROUND MAINTENANCE OF MATERIALIZED VIEWS.' DESCRIPTION ) AS DESCRI)
    SELECT APP_NAME
, to_char(start_time,'MON-YYYY') as month
, wh_name
, COST_CENTER as Project_ID
, APP_ID
,APP_NAME
, round(sum(total_credits_used),2) as total_credits_used
, owner
,Layer
FROM  MVTABLEF group by to_char(start_time,'MON-YYYY'), uc_name, APP_NAME, owner, wh_name, cost_center, app_id, app_name, layer;

--------extract wh usage 1:1 Splunk---------
WITH MVTABLEF AS (select 
USE_CASE  
,to_char(start_time,'MON-YYYY') as month
,WAREHOUSE_NAME
,WAREHOUSE_SIZE
,WAREHOUSE_TYPE
,COST_CENTER as "Project ID" 
,APP_ID 
,APP_NAME
,DOMAIN
,CREDITS_USED AS COST_USD 
,CREDITS_USED
,CREDIT_QUOTA
,OWNER
,LAYER
,acc.Environment AS Environment
,reg.Region AS REGION
from monitor_db.warehouse_monitoring.warehouse_consumption 
LEFT JOIN
(select CURRENT_ACCOUNT() Environment) as acc
left join 
(select CURRENT_REGION() Region) as reg

UNION ALL

SELECT 
B.UC_NAME AS USE_CASE
 ,to_char(m.start_time,'MON-YYYY') as month
 ,'MATERIALIZED_VIEW_MAINTENANCE - ' || REGEXP_SUBSTR(REGEXP_REPLACE(UC_NAME, '_', ' '),'SNO\\W+(\\w+)' , 1 , 1 , 'ie') AS WAREHOUSE_NAME
 ,WS.WAREHOUSE_SIZE AS WAREHOUSE_SIZE                
 ,WT.WAREHOUSE_TYPE AS WAREHOUSE_TYPE
 ,C.COST_CENTER as COST_CENTER                 
 ,C.COST_CENTER AS APP_ID 
 ,REGEXP_SUBSTR(REGEXP_REPLACE(UC_NAME, '_', ' '),'SNO\\W+(\\w+)' , 1 , 1 , 'ie') AS APP_NAME
 ,S.DOMAIN as DOMAIN                 
 ,M.TOTAL_CREDITS_USED AS COST_USD                
 ,M.TOTAL_CREDITS_USED AS CREDITS_USED
 ,CREDIT_QUOTA.CREDIT_QUOTA as CREDIT_QUOTA                 
 ,P.OWNER as OWNER   
 ,L.LAYER as LAYER
 ,acc.Environment as Environment
 ,reg.Region as Region  
    FROM (SELECT TABLE_NAME AS MATERIALIZED_VIEW, START_TIME, CREDITS_USED AS TOTAL_CREDITS_USED
    FROM SNOWFLAKE.ACCOUNT_USAGE.MATERIALIZED_VIEW_REFRESH_HISTORY ) AS M 
    JOIN                                   
    (SELECT DISTINCT TABLE_NAME, TABLE_OWNER AS UC_NAME FROM  SNOWFLAKE.ACCOUNT_USAGE.TABLES 
    WHERE TABLE_TYPE='MATERIALIZED VIEW' AND TABLE_OWNER IS NOT NULL) AS B
    ON M.MATERIALIZED_VIEW = B.TABLE_NAME
    LEFT JOIN
    (SELECT DISTINCT TAG_VALUE AS OWNER, OBJECT_NAME AS WH_NAME FROM SNOWFLAKE.ACCOUNT_USAGE.TAG_REFERENCES                   
    WHERE TAG_NAME='OWNER' AND DOMAIN='ROLE' ) AS P
    ON B.UC_NAME = P.WH_NAME
    LEFT JOIN
    (SELECT 'N/A' DOMAIN) AS S
    LEFT JOIN
    (SELECT DISTINCT OBJECT_NAME, TAG_VALUE AS COST_CENTER FROM SNOWFLAKE.ACCOUNT_USAGE.TAG_REFERENCES WHERE TAG_NAME='COST_CENTER'AND DOMAIN='ROLE') AS C
    ON P.WH_NAME = C.OBJECT_NAME
    LEFT JOIN
    (SELECT DISTINCT OBJECT_NAME, TAG_VALUE AS LAYER FROM SNOWFLAKE.ACCOUNT_USAGE.TAG_REFERENCES WHERE TAG_NAME='LAYER'AND DOMAIN='ROLE') AS L
    ON P.WH_NAME = L.OBJECT_NAME
    left join
    (select 'STANDART' WAREHOUSE_SIZE) as WS
        left join
    (select 'INTERNAL' WAREHOUSE_TYPE) as WT
            left join
    (select 'NA' CREDIT_QUOTA) as CREDIT_QUOTA
LEFT JOIN
(select CURRENT_ACCOUNT() Environment) as acc
left join 
(select CURRENT_REGION() Region) as reg
)

Select month
,max(USE_CASE) as USE_CASE 
,WAREHOUSE_NAME 
,max(WAREHOUSE_SIZE) as WAREHOUSE_SIZE
,max(WAREHOUSE_TYPE) as WAREHOUSE_TYPE
,max("Project ID") as "Project ID"
,max(APP_ID) as APP_ID 
,max(APP_NAME) as APP_NAME
,max(DOMAIN) as DOMAIN 
,round(sum(COST_USD * 3.64),2) as "Cost (USD)"   
,round(sum(CREDITS_USED),2) as "Credit Usage"
,max(CREDIT_QUOTA) as CREDIT_QUOTA 
,max(OWNER) as OWNER 
,max(LAYER) as LAYER 
,case
    when max(Environment)='NVS6DEVEUWEST1' then 'Development Environment' 
    when max(Environment)='NVS8PRDEUWEST1' then 'Production Environment' 
    when max(Environment)='NVS4PRDEAST1' then 'Production Environment' 
    when max(Environment)='NVS2DEVEAST1' then 'Development Environment' 
    when max(Environment)='NVS3QAEAST1' then 'QA Environment' 
    when max(Environment)='NVS7QAEUWEST1' then 'QA Environment' 
    else 'other'
end as Environment
,case
        when max(Region)='AWS_EU_WEST_1' then 'EU-WEST'
        when max(Region)='AWS_US_EAST_1' then 'US-EAST'
        else 'other'
end as Region
 from MVTABLEF group by month, WAREHOUSE_NAME 
;

------role hierarchy------

with roles_rec as (
  select distinct grantee_name, name
  from snowflake.account_usage.grants_to_roles
    where granted_on = 'ROLE' and granted_to = 'ROLE'
    and privilege in ('USAGE') and deleted_on is null
), roles as (
  select distinct name,sys_connect_by_path(grantee_name, ',') as grantee_path, level
    from roles_rece
    start with grantee_name = 'ACCOUNTADMIN'
    connect by grantee_name = prior name
    order by name
), final as (
select grantee_name, privilege, granted_on,
table_catalog as db, table_schema as schema, gr.name, grantee_path, level
,rank() over (partition by grantee_name, privilege, granted_on, table_catalog, table_schema, gr.name order by level desc) as rnk
  from snowflake.account_usage.grants_to_roles gr
  left join roles on gr.grantee_name = roles.name
  where TABLE_CATALOG = 'CUSTOMER_REFINEMENT'
  and TABLE_SCHEMA= 'MARKETING_AND_SALES_CONSOL'
  -- and gr.name = 'SI_VW_PRODUTO_CUP_MARKET'
  and granted_on <> 'ROLE'
  and privilege = 'SELECT' and deleted_on is null
  -- and (grantee_name = 'ACCOUNTADMIN'
  --      or grantee_name in (select name from roles))
)
select grantee_name, privilege, granted_on, db, schema, name, grantee_path
from final where rnk =1;
-------------------------

select * from snowflake.account_usage.grants_to_roles where NAME in ('SV_PERSONAL_SENSITIVE_GRANULAR','SV_PERSONAL_GRANULAR','SV_COMPENSATION_GRANULAR',
'SV_PERSONAL_SENSITIVE_AGGREGATED',
'SV_COMPENSATION_AGGREGATED',
'SV_PERSONAL_AGGREGATED',
'SV_WORK_EVENT_GRANULAR',
'SV_WORK_EVENT_AGGREGATED',
'SV_PERS_SENSITIVE_GRANULAR_MONTHLY',
'SV_PERS_GRANULAR_MONTHLY',
'SV_COMPENSATION_GRANULAR_MONTHLY',
'SV_PERS_SENSITIVE_AGG_MONTHLY',
'SV_COMPENSATION_AGG_MONTHLY',
'SV_PERS_AGG_MONTHLY',
'SV_WORK_EVENT_GRANULAR_MONTHLY',
'SV_WORK_EVENT_AGG_MONTHLY',
'SV_PERS_SENSITIVE_GRANULAR_RECON',
'MV_USER_ROLE_AUTHORIZATION',
'SV_COMPENSATION_PAY_LEVEL',
'SV_VARIABLE_PAY_SURVEY',
'SV_FIXED_PAY_SURVEY',
'SV_ALLOWANCE_BENEFITS_SURVEY',
'SV_PERSONAL_SENSITIVE_EQUITY_GRANULAR',
'SV_PERSONAL_SENSITIVE_OFFCYCLEPAY_GRANULAR') AND TABLE_CATALOG='PEOPLE_AND_ORGANIZATION_REFINEMENT' AND DELETED_ON IS NULL;
-------------------------------

SELECT object_construct('APP_ID',APP_ID,'APP_NAME',APP_NAME,'COST_CENTER', COST_CENTER,'DESCIPTION',DESCIPTION,'LAYER',LAYER,'OWNER',OWNER,'SUBJECT_AREA',SUBJECT_AREA,'USE_CASE',USE_CASE,'WAREHOUSE_NAME',WAREHOUSE_NAME) FROM (select name AS WAREHOUSE_NAME,L.tag_value as LAYER,D.tag_value as DESCIPTION, AI.TAG_VALUE as APP_ID, AN.tag_value as APP_NAME,CC.tag_value as COST_CENTER, O.tag_value AS OWNER, SA.tag_value AS SUBJECT_AREA, UC.tag_value AS USE_CASE from util_db.public.wh_list
 left join snowflake.account_usage.tag_references L on (L.object_name = wh_list.name) 

 left join snowflake.account_usage.tag_references D on (D.object_name = wh_list.name ) 
 left join snowflake.account_usage.tag_references AI on (AI.object_name = wh_list.name )
 left join snowflake.account_usage.tag_references AN on (AN.object_name = wh_list.name )
 left join snowflake.account_usage.tag_references CC on (CC.object_name = wh_list.name )
 left join snowflake.account_usage.tag_references O on (O.object_name = wh_list.name )
 left join snowflake.account_usage.tag_references SA on (SA.object_name = wh_list.name )
 left join snowflake.account_usage.tag_references UC on (UC.object_name = wh_list.name )
                                                                                                             
where L.tag_name='LAYER' and D.tag_name='DESCRIPTION' and AI.tag_name='APP_ID' and AN.tag_name='APP_NAME' and CC.tag_name='COST_CENTER'
AND O.tag_name='OWNER' AND SA.tag_name='SUBJECT_AREA' AND UC.tag_name='USE_CASE')
;

----------------------------------------------------------------
SELECT object_construct(*) AS TAGS 
FROM SNOWFLAKE_METADATA.ACCOUNT_USAGE.wh_tags_list
;

SELECT array_agg(object_construct(*))
FROM SNOWFLAKE_METADATA.ACCOUNT_USAGE.wh_tags_list;
-----------
CALL CONTROL_DB.UTILITY.SNAPSHOT_WH_TAGS();
--------
select * from CONTROL_DB.UTILITY.ROLE_TO_UC_TAGS_MAPPING_TABLE;
--------
execute task CONTROL_DB.UTILITY.TAG_WH_IN_ACCOUNT_FORCE_REFRESH;
show warehouses;