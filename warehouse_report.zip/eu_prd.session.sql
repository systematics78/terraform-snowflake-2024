with active_contracts as (
  select contract_number, max(expiration_date) t1, max(end_date) t2
  from SNOWFLAKE.ORGANIZATION_USAGE.CONTRACT_ITEMS
  group by contract_number
  having t1 >= current_date() or (t2 > current_date() and t1 is null)
),
capacity_balances as (
select 
  contract_number, 
  date,
  capacity_balance,
  row_number() over (partition by contract_number order by date desc) as row_num,
  currency
from SNOWFLAKE.ORGANIZATION_USAGE.REMAINING_BALANCE_DAILY
where contract_number in (select contract_number from active_contracts)
)
select sum(capacity_balance) as balance, any_value(currency) as currency
from capacity_balances
where row_num = 1;

select   to_char(usage_date,'MON-YYYY') as usage_date
,account_name as account_name
,round(sum(usage_in_currency), 2) as currency_used
,currency as currency
,region as region
,service_level as service_level 
from SNOWFLAKE.ORGANIZATION_USAGE.USAGE_IN_CURRENCY_DAILY 
where usage_date >= date_trunc(month,dateadd('month', -10,convert_timezone('Europe/Paris', current_timestamp())))   
and usage_date < convert_timezone('Europe/Paris', current_timestamp()) 
group by 1, 2, 4, 5, 6;

select * from SNOWFLAKE.ORGANIZATION_USAGE.USAGE_IN_CURRENCY_DAILY
where usage_date >= date_trunc(month,dateadd('month', -7,current_timestamp()))   
and usage_date <  current_timestamp() and usage_type='compute';

select * from monitor_db.warehouse_monitoring.warehouse_consumption;


-------------------------

SELECT object_construct('APP_ID',APP_ID,'APP_NAME',APP_NAME,'COST_CENTER',COST_CENTER,'DESCIPTION',DESCIPTION,'LAYER',LAYER,'OWNER',OWNER,'SUBJECT_AREA',SUBJECT_AREA,'USE_CASE',USE_CASE,'WAREHOUSE_NAME',WAREHOUSE_NAME) AS TAGS 
FROM (select wh_list.name AS WAREHOUSE_NAME
,L.tag_value as USE_CASE
,L.tag_name
,D.tag_value as DESCIPTION
,D.tag_name
,AI.tag_value as APP_ID
,AI.tag_name
,AN.tag_value as APP_NAME
,AN.tag_name
,CC.tag_value as COST_CENTER
,CC.tag_name
,O.tag_value AS OWNER
,O.tag_name
,SA.tag_value AS SUBJECT_AREA
,SA.tag_name
,UC.tag_value AS LAYER
,UC.tag_name
from util_db.public.wh_list
 full join snowflake.account_usage.tag_references AI on (util_db.public.wh_list.name = AI.object_name) 
 join snowflake.account_usage.tag_references AN on (AI.object_name = AN.object_name ) 
 join snowflake.account_usage.tag_references CC on (AN.object_name = CC.object_name ) 
 join snowflake.account_usage.tag_references D on (CC.object_name = D.object_name ) 
 join snowflake.account_usage.tag_references L on (D.object_name = L.object_name) 
 join snowflake.account_usage.tag_references O on (L.object_name = O.object_name ) 
 join snowflake.account_usage.tag_references SA on (O.object_name = SA.object_name ) 
 join snowflake.account_usage.tag_references UC on (SA.object_name = UC.object_name )

where AI.tag_name='APP_ID' AND AN.tag_name='APP_NAME' AND CC.tag_name='COST_CENTER' AND D.tag_name='DESCRIPTION' AND L.tag_name='USE_CASE'
AND O.tag_name='OWNER'  AND SA.tag_name='SUBJECT_AREA'  AND UC.tag_name='LAYER')
;

----------------------------------------------------------------
SELECT object_construct('APP_ID',APP_ID,'APP_NAME',APP_NAME,'COST_CENTER',COST_CENTER,'DESCRIPTION',DESCRIPTION,'LAYER',LAYER,'OWNER',OWNER,'SUBJECT_AREA',SUBJECT_AREA,'USE_CASE',USE_CASE,'WAREHOUSE_NAME',WAREHOUSE_NAME) AS TAGS 
FROM SNOWFLAKE_METADATA.ACCOUNT_USAGE.wh_tags_list
;
-----------
CALL CONTROL_DB.UTILITY.SNAPSHOT_WH_TAGS();
