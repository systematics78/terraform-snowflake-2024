with q1 as (
select m.table_name as materialized_view, m.start_time,m.end_time,m.credits_used as total_credit_used
, o.use_case as uc_name, o.owner, o.layer, o.app_name, o.app_id, o.cost_center, o.subject_area
,'IN ORDER TO PREVENT MATERIALIZED VIEWS FROM BECOMING OUT-OF-DATE, SNOWFLAKE PERFORMS AUTOMATIC BACKGROUND MAINTENANCE OF MATERIALIZED VIEWS.' DESCRIPTION
from SNOWFLAKE.ACCOUNT_USAGE.MATERIALIZED_VIEW_REFRESH_HISTORY m
inner join  CONTROL_DB.UTILITY.OBJECT_TO_UC_TAGS_MAPPING_TABLE o
on m.database_name||'.'||m.schema_name||'.'||m.table_name = o.object_name
and m.start_time > dateadd('month',-6,current_timestamp())
),
q2 as(
select m.table_name as materialized_view, m.start_time,m.end_time,m.credits_used as total_credit_used
, r.use_case as uc_name, r.owner, r.layer, r.app_name, r.app_id, r.cost_center, r.subject_area
,'IN ORDER TO PREVENT MATERIALIZED VIEWS FROM BECOMING OUT-OF-DATE, SNOWFLAKE PERFORMS AUTOMATIC BACKGROUND MAINTENANCE OF MATERIALIZED VIEWS.' DESCRIPTION
from SNOWFLAKE.ACCOUNT_USAGE.MATERIALIZED_VIEW_REFRESH_HISTORY m
inner join SNOWFLAKE.ACCOUNT_USAGE.TABLES t on m.database_name||'.'||m.schema_name||'.'||m.table_name = t.table_catalog||'.'||t.table_schema||'.'||t.table_name
inner join CONTROL_DB.UTILITY.ROLE_TO_UC_TAGS_MAPPING_TABLE r on r.role_name = t.table_owner
where TABLE_OWNER IS NOT NULL 
and t.deleted is null
and m.start_time > dateadd('month',-6,current_timestamp())
)
, final as (
select * from q1 where materialized_view in (select distinct materialized_view from q2)
union
select * from q2 where materialized_view not in (select distinct materialized_view from q1)
)
select * from final;
