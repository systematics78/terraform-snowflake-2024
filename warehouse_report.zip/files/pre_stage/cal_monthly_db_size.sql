with q1 as (
select usage_date,database_name
,case when database_name like 'COM_US%' then 'NONE_F1'
      when database_name ilike '%Refinement%' then 'REFINEMENT LAYER'
      when database_name = 'PUBLISH_DB' then 'PUBLISH LAYER'
    else 'OTHER'
 end as database_layer
, average_database_bytes/1024/1024/1024/1024 as average_database_size_tb
, average_failsafe_bytes/1024/1024/1024/1024 as average_failsafe_size_tb
, average_database_size_tb + average_failsafe_size_tb as total_database_size_tb
, case when datediff(month,deleted,current_date) >=6 then 0 when deleted is null then 1 end as deleted_1
from snowflake.account_usage.DATABASE_STORAGE_USAGE_HISTORY 
where usage_date between '2022-11-01' and '2023-02-06' 
and deleted_1 = 1
), q2 as (
select to_varchar(usage_date,'yyyy-Mon') as usage_month, database_name
, database_layer
,avg(total_database_size_tb) as db_size_tb
from q1
where database_layer<>'OTHER'
-- and database_name='COM_US_PHARMA_AUDIT'
group by usage_month, database_layer,database_name
)
select usage_month, database_layer,sum(db_size_tb) as db_size_tb
from q2
group by usage_month, database_layer
order by 1,2;