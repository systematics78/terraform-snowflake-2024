--netsh winhttp show proxy

SELECT query_id, warehouse_name,warehouse_size,
 total_elapsed_time,bytes_written_to_result,rows_produced,bytes_spilled_to_local_storage
,ROUND(unit_of_credit*total_elapsed_time / 60/60,2)  total_credit
,total_credit*3.00 query_cost --change based on how much you are paying for a credit
FROM (
select query_id,query_text, role_name,warehouse_name,warehouse_size,
 total_elapsed_time,bytes_written_to_result,rows_produced,bytes_spilled_to_local_storage
 ,start_time
 ,end_time
 ,total_elapsed_time/1000   total_elapsed_sec
 ,CASE WHEN warehouse_size = 'X-Small'    THEN 1
         WHEN warehouse_size = 'Small'      THEN 2
         WHEN warehouse_size = 'Medium'     THEN 4
         WHEN warehouse_size = 'Large'      THEN 8
         WHEN warehouse_size = 'X-Large'    THEN 16
         WHEN warehouse_size = '2X-Large'   THEN 32
         WHEN warehouse_size = '3X-Large'   THEN 64
         WHEN warehouse_size = '4X-Large'   THEN 128
   ELSE 1    
   END unit_of_credit
from snowflake.account_usage.query_history where query_id='01a7075a-3201-d8cf-0000-ab790e0551fe'
    );

---find ext table from query_text column  
 select query_id,query_text, role_name,warehouse_name,warehouse_size,
 total_elapsed_time,bytes_written_to_result,rows_produced,bytes_spilled_to_local_storage
 from snowflake.account_usage.query_history 
 where query_id='01a7075a-3201-d8cf-0000-ab790e0551fe';

 --size of external table 
select table_catalog as db_name,table_schema as schema_name,table_name,row_count,bytes
 from snowflake.account_usage.tables 
 where table_catalog='CURATED_RAW' 
 and table_schema ='EMPLOYEE_FIELDFORCE_ACTION_UNIFIED' and table_name ='EMPLOYEE_FIELDFORCE_TOT_EXT'
 and deleted is null;    