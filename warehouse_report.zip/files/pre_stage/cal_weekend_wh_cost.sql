select   date(start_time) as start_time,
entity_id,
name,
service_type,
sum(credits_used) as credits_used,
sum(credits_used_compute) as credits_compute, 
sum(credits_used_cloud_services) as credits_cloud 
from SNOWFLAKE.ACCOUNT_USAGE.METERING_HISTORY 
where start_time > add_months(current_date,-2)
and DAYOFWEEK(start_time) in (0,6)
and service_type='WAREHOUSE_METERING' and entity_id<>0
group by 1, 2, 3, 4 
order by 1,3;