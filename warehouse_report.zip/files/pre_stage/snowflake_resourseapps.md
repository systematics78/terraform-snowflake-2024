# Requires Azure PowerShell module
# Ensure you're logged in
# Connect-AzAccount
 
# Owner Service Principal ID (the new owner)
$ownerServicePrincipalId = "662b50a5-28f7-42b9-82e0-19d41151f5e5"
 
# List of Target Application Service Principal IDs
$targetAppServicePrincipalIds = @(
    "f2067106-3ba2-4ed0-bb67-d037c806975d", # e448f982-9e8e-492f-b87e-e8258693416a
    "90e201a9-3440-4bbf-b4f2-0be40cb22be9", # fda91a8e-d410-4a8f-84b7-325c1c96af3e
    "825e7fc9-568d-4c6f-ab56-10e417cdb66a", # 52069176-1917-458e-8755-92cb47c4ebe3
    "57cab907-c890-4d0d-8ea7-6bebe567d794", # cd9cf2e5-3291-452c-95ba-f64f4a1c39af
    "ad815105-7fff-43e4-b1a3-f19704acd87f", # ed2ffede-b791-408d-940e-b15888e69a34
    "dbe772ad-5da4-4527-8b9e-ed45d62b75ad", # GlassBox_RITM2412952_46074
    "0ccb298c-1973-451d-ade1-55f03ef24315", # GlassBox_RITM2412969_46074
    "b4855182-11b6-49fc-a136-a588c088ee33", # GlassBox_RITM2345506_46074
    "662b50a5-28f7-42b9-82e0-19d41151f5e5"  # F1_Snowflake_RITM5936921_clr_45879 (Main Application)
)
 
# Assigning the owner to each application
foreach ($appId in $targetAppServicePrincipalIds) {
    try {
        Add-AzADAppOwner -ObjectId $appId -RefObjectId $ownerServicePrincipalId
        Write-Host "Successfully assigned owner to application with Service Principal ID: $appId"
    } catch {
        Write-Host "Failed to assign owner to application with Service Principal ID: $appId. Error: $_"
    }
}


Name
 
 
	
Object ID
 
	
Application ID
 
	
Homepage URL
 
	
Created on
 
 
	
Certificate Expiry Status
 
	
Active Certificate Expiry Date
 
	
Identifier URI (Entity ID)
 
 
 
F
F1_IMMUTA_NPROD_RITM5832037_45879
	006a8ae1-27cb-4f5a-beea-faf41fc9129a	d273a8d1-88ce-4479-b7d0-574b6124b6e0	https://account.activedirectory.windowsazure.com:444/applications/default.aspx?metadata=customappsso|ISV9.1|primary|z	11/17/2023	-	-	d273a8d1-88ce-4479-b7d0-574b6124b6e0

 
F
F1_IMMUTA_NPROD_RITM5382367_45879
	06416040-2624-4b9e-9f4d-a41035ce9b23	e055a9e4-7228-42bd-9c6a-83decc9a4e23	https://account.activedirectory.windowsazure.com:444/applications/default.aspx?metadata=customappsso|ISV9.1|primary|z	7/28/2023	Current	7/28/2026	https://imus-nprd-novartis.hosted.immutacloud.com/, e055a9e4-7228-42bd-9c6a-83decc9a4e23

 
F
F1_IMMUTA_PROD_RITM5383532_45879
	8ca37b4d-d2b4-48f3-8431-c03a047e94de	a6272329-1cac-4283-9fbb-16e64d9f5dcb	https://account.activedirectory.windowsazure.com:444/applications/default.aspx?metadata=customappsso|ISV9.1|primary|z	7/28/2023	Current	7/28/2026	https://imus-prd-novartis.hosted.immutacloud.com/, a6272329-1cac-4283-9fbb-16e64d9f5dcb

 
F
F1_IMMUTA_PROD_RITM5885071_45879
	d56d5254-7b94-47ba-a978-41e8a54ca1f3	a5658740-97d1-4249-bb1c-524c3ef70c29	https://account.activedirectory.windowsazure.com:444/applications/default.aspx?metadata=customappsso|ISV9.1|primary|z	11/29/2023	 	 	 