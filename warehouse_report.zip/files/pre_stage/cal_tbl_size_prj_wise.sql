select r.role_name,m.table_catalog, m.table_schema, m.table_name,t.table_type
, sum(m.active_bytes)/1024/1024/1024 as active_bytes_gb
, sum(m.time_travel_bytes)/1024/1024/1024 as time_travel_bytes_gb
, sum(m.failsafe_bytes)/1024/1024/1024 as failsafe_bytes_gb
, sum(retained_for_clone_bytes)/1024/1024/1024 as retained_for_clone_bytes_gb
, active_bytes_gb+time_travel_bytes_gb+failsafe_bytes_gb+retained_for_clone_bytes_gb as total_size_gb
from snowflake.account_usage.tables t
inner join control_db.utility.role_to_uc_tags_mapping_table r on t.table_owner = r.role_name 
inner join snowflake.account_usage.table_storage_metrics m 
        on t.table_catalog = m.table_catalog and t.table_schema = m.table_schema
        and t.table_name = m.table_name
where r.cost_center='PRJ0198697'
and t.table_type in ('BASE TABLE','MATERIALIZED VIEW') and t.deleted is null
group by r.role_name,m.table_catalog, m.table_schema, m.table_name,t.table_type
order by 1,2,3,6 desc;