CREATE OR REPLACE PROCEDURE MANAGE_WAREHOUSE_SIZE()
  RETURNS STRING
  LANGUAGE JAVASCRIPT
  EXECUTE AS CALLER
AS
$$
var current_utc_date = new Date();
var offset = 5; // Offset for America/New_York (without considering Daylight Saving Time)
if (current_utc_date.getUTCMonth() > 2 && current_utc_date.getUTCMonth() < 11) {
    offset = 4; // Adjusting for Daylight Saving Time
}
var local_hour = current_utc_date.getUTCHours() - offset;
var current_minute = current_utc_date.getUTCMinutes();
var result = '';

if (current_utc_date.getUTCDay() === 5) { // 0 is Sunday, 6 is Saturday, so 5 is Friday
    if (local_hour === 6 && current_minute >= 30) {
        result = 'Resizing to 4XL for Friday peak load';
        snowflake.execute({sqlText: "ALTER WAREHOUSE COM_US_PHARMA_AWB_WH_4X SET WAREHOUSE_SIZE = '4XL';"});
    } else if (local_hour === 8 && current_minute >= 30) {
        result = 'Resizing to SMALL size post peak';
        snowflake.execute({sqlText: "ALTER WAREHOUSE COM_US_PHARMA_AWB_WH_4X SET WAREHOUSE_SIZE = 'SMALL';"});
    }
} else {
    result = 'Not Friday. Ensuring SMALL size';
    snowflake.execute({sqlText: "ALTER WAREHOUSE COM_US_PHARMA_AWB_WH_4X SET WAREHOUSE_SIZE = 'SMALL';"});
}
return result;
$$;


CREATE OR REPLACE PROCEDURE MANAGE_WAREHOUSE_SIZE()
  RETURNS STRING
  LANGUAGE JAVASCRIPT
  EXECUTE AS CALLER
AS
$$
var current_utc_date = new Date();
var offset = 5; // Offset for America/New_York (without considering Daylight Saving Time)
if (current_utc_date.getUTCMonth() > 2 && current_utc_date.getUTCMonth() < 11) {
    offset = 4; // Adjusting for Daylight Saving Time
}
var local_day = (current_utc_date.getUTCDay() - offset + 7) % 7; // Correcting for the timezone offset
var result = '';

if (local_day === 5) { // 0 is Sunday, 6 is Saturday, so 5 is Friday in local timezone
    result = 'Resizing to 4XL for Friday';
    snowflake.execute({sqlText: "ALTER WAREHOUSE COM_US_PHARMA_AWB_WH_4X SET WAREHOUSE_SIZE = '4XL';"});
} else {
    result = 'Ensuring SMALL size as it is not Friday';
    snowflake.execute({sqlText: "ALTER WAREHOUSE COM_US_PHARMA_AWB_WH_4X SET WAREHOUSE_SIZE = 'SMALL';"});
}
return result;
$$;
