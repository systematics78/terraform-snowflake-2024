with q1 as (
select query_id,query_start_time,direct_objects_accessed,
   f.value as val_col,index as idx
from snowflake.account_usage.access_history p,
   lateral flatten(input => p.direct_objects_accessed) f
),q2 as (
select query_id,query_start_time, f.key, replace(f.value,'"','') as value, idx
from q1,
     lateral flatten(input => q1.val_col) f
      where key in ('objectDomain', 'objectName')
),
q3 as (
  select query_id,query_start_time, listagg(key||':'||value||':'||idx,':') within group (order by idx,key) output
  from q2
  group by query_id,query_start_time, idx
),
q4 as (
  select query_id,query_start_time,split_part(output,':',5) as table_name
 from q3
  where upper(output) like any ('%EXTERNAL TABLE%')
),
ext_tbl as (
  select to_char(query_start_time,'MM-YYYY') query_month, table_name,query_id
  , count(1) over (partition by table_name, query_month order by query_month desc) as table_accessed_count
  from q4  
),
qry_his as (
  select query_id,warehouse_name,to_char(start_time,'MM-YYYY') month,total_elapsed_time
  from snowflake.account_usage.query_history
),
wh as (
  select to_char(start_time,'MM-YYYY') as month, warehouse_name, sum(credits_used) as credits_used_by_month
  from snowflake.account_usage.warehouse_metering_history
  group by month, warehouse_name
),
final as (
select et.query_month
, split_part(et.table_name,'.',1) as database_name
, split_part(et.table_name,'.',2) as schema_name
, split_part(et.table_name,'.',3) as table_name
, et.query_id
, et.table_accessed_count
, qh.total_elapsed_time/60000 as total_elapsed_time_min
, wh.credits_used_by_month/30/24/60 as credits_used_by_month
from ext_tbl as et
inner join qry_his as qh on et.query_id = qh.query_id and et.query_month = qh.month
inner join wh on qh.warehouse_name = wh.warehouse_name and qh.month = wh.month
  )
,tbl as (select table_catalog as database_name,table_schema as schema_name, table_name, table_type, bytes
from snowflake.account_usage.tables where deleted is null)
select f.* , t.bytes, t.table_type
from final as f 
left join tbl as t on f.database_name = t.database_name and f.schema_name = t.schema_name and f.table_name = t.table_name;


