--For last 12 month data
select date(date_trunc(month,start_time)) as start_time,
name, service_type, sum(credits_used) as credits_used,sum(credits_used_compute) as credits_compute,
sum(credits_used_cloud_services) as credits_cloud 
from SNOWFLAKE.ACCOUNT_USAGE.METERING_HISTORY 
where date(start_time)>=dateadd(month,-12,current_date())
group by 1, 2, 3 
order by 1,2,3;