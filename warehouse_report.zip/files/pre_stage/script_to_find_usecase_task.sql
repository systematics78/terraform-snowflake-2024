/*
This script is use to find the task which is created by the Use Case team to execute on Weekend also.
This will generate the script to change the scheduled time of task to run only on weekdays.
*/

show tasks in account;
select split_part("owner",'_',4) as usecase_name
,"database_name","schema_name","name","schedule"
,"state","predecessors","owner",replace("schedule",'* UTC','1-5 UTC') as new_schedule
,'ALTER TASK IF EXISTS ' || "database_name"||'.'||"schema_name"||'.'||"name" || ' suspend;' as suspend_task
,'ALTER TASK IF EXISTS ' || "database_name"||'.'||"schema_name"||'.'||"name" || ' SET SCHEDULE = \'' || replace("schedule",'* UTC','1-5 UTC\';') as alter_script
,'ALTER TASK IF EXISTS ' || "database_name"||'.'||"schema_name"||'.'||"name" || ' resume;' as resume_task
from TABLE(RESULT_SCAN(LAST_QUERY_ID())) where "state"<>'suspended' and "schedule" is not null
and split_part("schedule",' ',-2) = '*'
and not "owner" like any ('ACCOUNTADMIN','%_UCE_ADMIN','%_OPS_ADMIN')
order by 1;