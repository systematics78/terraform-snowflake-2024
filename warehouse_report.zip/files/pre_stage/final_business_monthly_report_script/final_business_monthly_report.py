import configparser
import pandas as pd
import snowflake.connector
from openpyxl.workbook import Workbook
from snowflake.sqlalchemy import URL
from sqlalchemy import create_engine
import time

# Reading the configuration file with 'configparser' package
config_sf = configparser.ConfigParser()
config_sf.sections()
config_sf.read('tmp/config_sf.ini')

##US DEV
# Assigning snowflake configuration (Environment)
usdev_sfAccount = config_sf['Snowflake_US_DEV']['sfAccount']
usdev_sfUser = config_sf['Snowflake_US_DEV']['sfUser']
usdev_sfWarehouse = config_sf['Snowflake_US_DEV']['sfWarehouse']
usdev_sfDatabase = config_sf['Snowflake_US_DEV']['sfDatabase']
usdev_sfSchema = config_sf['Snowflake_US_DEV']['sfSchema']
usdev_sfRole = config_sf['Snowflake_US_DEV']['sfRole']

# Connect to Snowflake using the configurations above
usdev_conn = create_engine(URL(
    user=usdev_sfUser,
    authenticator="externalbrowser",
    account=usdev_sfAccount,
    warehouse=usdev_sfWarehouse,
    database=usdev_sfDatabase,
    schema=usdev_sfSchema,
    role=usdev_sfRole
    ))

##US QA
# Assigning snowflake configuration (Environment)
usqa_sfAccount = config_sf['Snowflake_US_QA']['sfAccount']
usqa_sfUser = config_sf['Snowflake_US_QA']['sfUser']
usqa_sfWarehouse = config_sf['Snowflake_US_QA']['sfWarehouse']
usqa_sfDatabase = config_sf['Snowflake_US_QA']['sfDatabase']
usqa_sfSchema = config_sf['Snowflake_US_QA']['sfSchema']
usqa_sfRole = config_sf['Snowflake_US_QA']['sfRole']

# Connect to Snowflake using the configurations above
usqa_conn = create_engine(URL(
    user=usqa_sfUser,
    authenticator="externalbrowser",
    account=usqa_sfAccount,
    warehouse=usqa_sfWarehouse,
    database=usqa_sfDatabase,
    schema=usqa_sfSchema,
    role=usqa_sfRole
    ))

##US PRD
# Assigning snowflake configuration (Environment)
usprd_sfAccount = config_sf['Snowflake_US_PRD']['sfAccount']
usprd_sfUser = config_sf['Snowflake_US_PRD']['sfUser']
usprd_sfWarehouse = config_sf['Snowflake_US_PRD']['sfWarehouse']
usprd_sfDatabase = config_sf['Snowflake_US_PRD']['sfDatabase']
usprd_sfSchema = config_sf['Snowflake_US_PRD']['sfSchema']
usprd_sfRole = config_sf['Snowflake_US_PRD']['sfRole']

# Connect to Snowflake using the configurations above
usprd_conn = create_engine(URL(
    user=usprd_sfUser,
    authenticator="externalbrowser",
    account=usprd_sfAccount,
    warehouse=usprd_sfWarehouse,
    database=usprd_sfDatabase,
    schema=usprd_sfSchema,
    role=usprd_sfRole
    ))

##EU DEV
# Assigning snowflake configuration (Environment)
eudev_sfAccount = config_sf['Snowflake_EU_DEV']['sfAccount']
eudev_sfUser = config_sf['Snowflake_EU_DEV']['sfUser']
eudev_sfWarehouse = config_sf['Snowflake_EU_DEV']['sfWarehouse']
eudev_sfDatabase = config_sf['Snowflake_EU_DEV']['sfDatabase']
eudev_sfSchema = config_sf['Snowflake_EU_DEV']['sfSchema']
eudev_sfRole = config_sf['Snowflake_EU_DEV']['sfRole']

# Connect to Snowflake using the configurations above
eudev_conn = create_engine(URL(
    user=eudev_sfUser,
    authenticator="externalbrowser",
    account=eudev_sfAccount,
    warehouse=eudev_sfWarehouse,
    database=eudev_sfDatabase,
    schema=eudev_sfSchema,
    role=eudev_sfRole
    ))

##EU QA
# Assigning snowflake configuration (Environment)
euqa_sfAccount = config_sf['Snowflake_EU_QA']['sfAccount']
euqa_sfUser = config_sf['Snowflake_EU_QA']['sfUser']
euqa_sfWarehouse = config_sf['Snowflake_EU_QA']['sfWarehouse']
euqa_sfDatabase = config_sf['Snowflake_EU_QA']['sfDatabase']
euqa_sfSchema = config_sf['Snowflake_EU_QA']['sfSchema']
euqa_sfRole = config_sf['Snowflake_EU_QA']['sfRole']

# Connect to Snowflake using the configurations above
euqa_conn = create_engine(URL(
    user=euqa_sfUser,
    authenticator="externalbrowser",
    account=euqa_sfAccount,
    warehouse=euqa_sfWarehouse,
    database=euqa_sfDatabase,
    schema=euqa_sfSchema,
    role=euqa_sfRole
    ))


##EU-PROD Conn
# Assigning snowflake configuration (Environment)
prd_sfAccount = config_sf['Snowflake_EU_PROD']['sfAccount']
prd_sfUser = config_sf['Snowflake_EU_PROD']['sfUser']
prd_sfWarehouse = config_sf['Snowflake_EU_PROD']['sfWarehouse']
prd_sfDatabase = config_sf['Snowflake_EU_PROD']['sfDatabase']
prd_sfSchema = config_sf['Snowflake_EU_PROD']['sfSchema']
prd_sfRole = config_sf['Snowflake_EU_PROD']['sfRole']

# Connect to Snowflake using the configurations above
euprd_conn = create_engine(URL(
    user=prd_sfUser,
    authenticator="externalbrowser",
    account=prd_sfAccount,
    warehouse=prd_sfWarehouse,
    database=prd_sfDatabase,
    schema=prd_sfSchema,
    role=prd_sfRole
    ))

# Connect to Snowflake EU PROD to truncate table
prd_exec_conn = snowflake.connector.connect(
    user=prd_sfUser,
    authenticator="externalbrowser",
    account=prd_sfAccount,
    warehouse=prd_sfWarehouse,
    database=prd_sfDatabase,
    schema=prd_sfSchema,
    role=prd_sfRole
    )

###Loading Global WH Table
# Open and read the file as a single buffer
fd_wh = open('scripts/global_wh_to_uc_tags_mapping_query.sql', 'r')
global_wh_to_uc_tags_mapping_query = fd_wh.read()
fd_wh.close()

#creating dataframe for EU DEV script
eudev_wh_to_uc_tags_df = pd.read_sql_query(global_wh_to_uc_tags_mapping_query, con=eudev_conn)
#creating dataframe for EU QA script
euqa_wh_to_uc_tags_df = pd.read_sql_query(global_wh_to_uc_tags_mapping_query, con=euqa_conn)
#creating dataframe for EU PRD script
euprd_wh_to_uc_tags_df = pd.read_sql_query(global_wh_to_uc_tags_mapping_query, con=euprd_conn)
#creating dataframe for US DEV script
usdev_wh_to_uc_tags_df = pd.read_sql_query(global_wh_to_uc_tags_mapping_query, con=usdev_conn)
# #creating dataframe for US QA script
usqa_wh_to_uc_tags_df = pd.read_sql_query(global_wh_to_uc_tags_mapping_query, con=usqa_conn)
# #creating dataframe for US PRD script
usprd_wh_to_uc_tags_df = pd.read_sql_query(global_wh_to_uc_tags_mapping_query, con=usprd_conn)

#truncate table from Prod global table
trunc_query = """truncate table global_wh_to_uc_tags_mapping_table;"""
cursor = prd_exec_conn.cursor()
cursor.execute(trunc_query)

#writing EU-DEV data to EU-PRD table
eudev_wh_to_uc_tags_df.to_sql('global_wh_to_uc_tags_mapping_table', con=euprd_conn, index=False, if_exists='append')
print("EU DEV warehouse consumption loading done...")

#writing EU-QA data to EU-PRD table
euqa_wh_to_uc_tags_df.to_sql('global_wh_to_uc_tags_mapping_table', con=euprd_conn, index=False, if_exists='append')
print("EU QA warehouse consumption loading done...")

#writing EU-PRD data to EU-PRD table
euprd_wh_to_uc_tags_df.to_sql('global_wh_to_uc_tags_mapping_table', con=euprd_conn, index=False, if_exists='append')
print("EU PRD warehouse consumption loading done...")

#writing US-DEV data to EU-PRD table
usdev_wh_to_uc_tags_df.to_sql('global_wh_to_uc_tags_mapping_table', con=euprd_conn, index=False, if_exists='append')
print("US DEV warehouse consumption loading done...")
# # sleep
# #writing US-QA data to EU-PRD table
usqa_wh_to_uc_tags_df.to_sql('global_wh_to_uc_tags_mapping_table', con=euprd_conn, index=False, if_exists='append')
print("US QA warehouse consumption loading done...")

# #writing US-PRD data to EU-PRD table
usprd_wh_to_uc_tags_df.to_sql('global_wh_to_uc_tags_mapping_table', con=euprd_conn, index=False, if_exists='append')
print("US PRD warehouse consumption loading done...")



###Loading Global MV Table
#Open and read the file as a single buffer
fd = open('scripts/global_mv_to_uc_tags_mapping_query.sql', 'r')
global_mv_to_uc_tags_mapping_query = fd.read()
fd.close()

#creating dataframe for EU DEV script
eudev_mv_to_uc_tags_df = pd.read_sql_query(global_mv_to_uc_tags_mapping_query, con=eudev_conn)
#creating dataframe for EU QA script
euqa_mv_to_uc_tags_df = pd.read_sql_query(global_mv_to_uc_tags_mapping_query, con=euqa_conn)
#creating dataframe for EU PRD script
euprd_mv_to_uc_tags_df = pd.read_sql_query(global_mv_to_uc_tags_mapping_query, con=euprd_conn)

#truncate table from Prod global table
trunc_query = """truncate table global_mv_to_uc_tags_mapping_table;"""
cursor = prd_exec_conn.cursor()
cursor.execute(trunc_query)

#writing EU-DEV data to EU-PRD table
eudev_mv_to_uc_tags_df.to_sql('global_mv_to_uc_tags_mapping_table', con=euprd_conn, index=False, if_exists='append')
print("EU DEV Materialized View consumption loading done...")
# sleep
#writing EU-QA data to EU-PRD table
euqa_mv_to_uc_tags_df.to_sql('global_mv_to_uc_tags_mapping_table', con=euprd_conn, index=False, if_exists='append')
print("EU QA Materialized View consumption loading done...")

#writing EU-PRD data to EU-PRD table
euprd_mv_to_uc_tags_df.to_sql('global_mv_to_uc_tags_mapping_table', con=euprd_conn, index=False, if_exists='append')
print("EU PRD Materialized View consumption loading done...")



###Buiness Report
# Open and read the file as a single buffer
bus_fd = open('scripts/business_wh_mv_credit_report.sql', 'r')
business_report_query = bus_fd.read()
bus_fd.close()

euprd_business_report_df = pd.read_sql_query(business_report_query, con=euprd_conn)
#creating excel report
euprd_business_report_df.to_excel("report/business_report.xlsx",
             sheet_name='montly_business_report', index=False)