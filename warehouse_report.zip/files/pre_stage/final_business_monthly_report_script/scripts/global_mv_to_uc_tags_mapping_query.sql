select 
    distinct m.table_name as materialized_view_name,m.database_name,m.schema_name
    , r.app_id, r.app_name,r.cost_center,'NA' as domain,r.layer,r.owner
    ,r.subject_area, r.use_case,current_account() as environment,current_region() as region
    ,'IN ORDER TO PREVENT MATERIALIZED VIEWS FROM BECOMING OUT-OF-DATE
    , SNOWFLAKE PERFORMS AUTOMATIC BACKGROUND MAINTENANCE OF MATERIALIZED VIEWS.' DESCRIPTION
    from SNOWFLAKE.ACCOUNT_USAGE.MATERIALIZED_VIEW_REFRESH_HISTORY m
    inner join SNOWFLAKE.ACCOUNT_USAGE.TABLES t on m.database_name||'.'||m.schema_name||'.'||m.table_name = t.table_catalog||'.'||t.table_schema||'.'||t.table_name
    inner join CONTROL_DB.UTILITY.ROLE_TO_UC_TAGS_MAPPING_TABLE r on r.role_name = t.table_owner
    where TABLE_OWNER IS NOT NULL 
    and t.deleted is null
    and m.start_time > dateadd('month',-6,current_timestamp())
    and m.table_name not in (select split_part(object_name,'.',-1) as materialized_view_name 
from control_db.utility.object_to_uc_tags_mapping_table)
union all
select 
    split_part(OBJECT_NAME,'.',-1) as materialized_view_name,
    split_part(OBJECT_NAME,'.',1) as database_name,
    split_part(OBJECT_NAME,'.',2) as schema_name,
    APP_ID,
    APP_NAME,
    COST_CENTER,
    'NA' domain,
    LAYER,
    OWNER,
    SUBJECT_AREA,
    USE_CASE,
    current_account() as environment,
    current_region() as region,
    DESCRIPTION
from control_db.utility.object_to_uc_tags_mapping_table;