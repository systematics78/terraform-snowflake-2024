with q1 as (
select TO_VARCHAR(date,'YYYY-MON') as month
,case when account_name like any ('NVS2%','NVS6%') then 'Development Environment'
    when account_name like any ('NVS3%','NVS7%') then 'QA Environment'
    when account_name like any ('NVS4%','NVS8%') then 'Production Environment' end as environment
,split_part(region,'_',2)||'-'||split_part(region,'_',3) as region 
,max(effective_rate) as effective_rate
from SNOWFLAKE.ORGANIZATION_USAGE.RATE_SHEET_DAILY where service_type='COMPUTE'
group by month,account_name,region
),
q2 as (
select coalesce(q2.use_case,'Tags information not available') as use_case
,TO_VARCHAR(start_time,'YYYY-MON') as month,wmh.warehouse_name
,coalesce(warehouse_size,'Tags information not available') as warehouse_size
,coalesce(warehouse_type,'Tags information not available') as warehouse_type
,coalesce(q2.cost_center,'Tags information not available') as project_id
,coalesce(q2.app_id,'Tags information not available') as app_id
,coalesce(q2.app_name,'Tags information not available') as app_name
,coalesce(q2.domain,'Tags information not available') as domain
,round(sum(credits_used),2) as credits_used
,round(sum(credits_used),2) as Credit_Usage
,coalesce(credits_quota,500) as credits_quota
,coalesce(q2.owner,'Tags information not available') as owner
,coalesce(q2.layer,'Tags information not available') as layer
,case when wmh.account_name like any ('NVS2%','NVS6%') then 'Development Environment'
when wmh.account_name like any ('NVS3%','NVS7%') then 'QA Environment'
when wmh.account_name like any ('NVS4%','NVS8%') then 'Production Environment' end as environment
,split_part(wmh.region,'_',2)||'-'||split_part(wmh.region,'_',3) as region
,round(sum(credits_used_compute),2) as credits_used_compute,round(sum(credits_used_cloud_services),2) as credits_used_cloud_services
from snowflake.organization_usage.warehouse_metering_history wmh
left join control_db.utility.global_wh_to_uc_tags_mapping_table q2 on (wmh.warehouse_name = q2.warehouse_name and wmh.account_name = q2.environment and wmh.region = q2.region)
where wmh.account_name like any ('NVS2%','NVS3%','NVS4%','NVS6%','NVS7%','NVS8%')
and TO_VARCHAR(start_time,'YYYY-MM')=TO_VARCHAR(add_months(current_date(),-1),'YYYY-MM')
group by month,wmh.account_name,wmh.region,wmh.warehouse_name
,q2.use_case,q2.app_id,q2.app_name,q2.domain,q2.owner,q2.layer,q2.cost_center,warehouse_size,warehouse_type,credits_quota
union all
select coalesce(gmv.use_case,'Tags information not available') as use_case
, TO_VARCHAR(usage_date,'YYYY-MON') as month
, coalesce('Materialized_View_Maintenance - ' || use_case,'Materialized_View_Maintenance') as warehouse_name
, 'STANDARD' as WAREHOUSE_SIZE
, 'Snowflake Service' as WAREHOUSE_TYPE
,coalesce(gmv.cost_center,'Tags information not available') as project_id
,coalesce(gmv.app_id,'Tags information not available') as app_id
,coalesce(gmv.app_name,'Tags information not available') as app_name
,coalesce(gmv.domain,'Tags information not available') as domain
,round(sum(credits_used),2) as credits_used
,round(sum(credits_used),2) as Credit_Usage
,null as credits_quota
,coalesce(gmv.owner,'Tags information not available') as owner
,coalesce(gmv.layer,'Tags information not available') as layer
,case when mv.account_name like any ('NVS2%','NVS6%') then 'Development Environment'
when mv.account_name like any ('NVS3%','NVS7%') then 'QA Environment'
when mv.account_name like any ('NVS4%','NVS8%') then 'Production Environment' end as environment
,split_part(mv.region,'_',2)||'-'||split_part(mv.region,'_',3) as region
,0 as credits_used_compute,0 as credits_used_cloud_services 
from snowflake.organization_usage.materialized_view_refresh_history mv 
left join control_db.utility.global_mv_to_uc_tags_mapping_table gmv
on (mv.database_name = gmv.database_name and mv.schema_name = gmv.schema_name and mv.table_name = gmv.materialized_view_name
    and mv.account_name = gmv.environment and mv.region = gmv.region)
where TO_VARCHAR(usage_date,'YYYY-MM')=TO_VARCHAR(add_months(current_date(),-1),'YYYY-MM')    
group by use_case,month,warehouse_name, project_id,app_id,app_name,domain,owner,layer,mv.account_name,mv.region
)
select USE_CASE as "USE CASE",
q2.MONTH as "MONTH ",
WAREHOUSE_NAME as "WAREHOUSE NAME",
WAREHOUSE_SIZE as "WAREHOUSE SIZE",
WAREHOUSE_TYPE as "WAREHOUSE TYPE",
PROJECT_ID as "PROJECT ID",
APP_ID as "APP ID",
APP_NAME as "APP NAME",
DOMAIN as "DOMAIN ",
credits_used*effective_rate as "COST(USD)",
Credit_Usage as "CREDIT USAGE",
CREDITS_QUOTA as "CREDITS QUOTA",
OWNER as "OWNER ",
LAYER as "LAYER ",
q2.ENVIRONMENT as "ENVIRONMENT ",
q2.REGION as "REGION "
from q1 
join q2 on q1.region = q2. region and q1.environment = q2.environment and q1.month = q2.month
;