with q as (
select distinct split_part(ACCESS_HISTORY.DIRECT_OBJECTS_ACCESSED[0]:objectName::VARCHAR,'.',0) as db_name
,split_part(ACCESS_HISTORY.DIRECT_OBJECTS_ACCESSED[0]:objectName::VARCHAR,'.',2) as schema_name
,split_part(ACCESS_HISTORY.DIRECT_OBJECTS_ACCESSED[0]:objectName::VARCHAR,'.',-1) as table_name
,1 as flag
FROM SNOWFLAKE.ACCOUNT_USAGE.ACCESS_HISTORY 
where 1=1
and date(QUERY_START_TIME) >= DATEADD(MONTH,-2,CURRENT_DATE())
union
select distinct split_part(ACCESS_HISTORY.BASE_OBJECTS_ACCESSED[0]:objectName::VARCHAR,'.',0) as db_name
,split_part(ACCESS_HISTORY.BASE_OBJECTS_ACCESSED[0]:objectName::VARCHAR,'.',2) as schema_name
,split_part(ACCESS_HISTORY.BASE_OBJECTS_ACCESSED[0]:objectName::VARCHAR,'.',-1) as table_name
,1 as flag
FROM SNOWFLAKE.ACCOUNT_USAGE.ACCESS_HISTORY 
where 1=1
and date(QUERY_START_TIME) >= DATEADD(MONTH,-2,CURRENT_DATE())
union
select distinct split_part(ACCESS_HISTORY.OBJECTS_MODIFIED[0]:objectName::VARCHAR,'.',0) as db_name
,split_part(ACCESS_HISTORY.OBJECTS_MODIFIED[0]:objectName::VARCHAR,'.',2) as schema_name
,split_part(ACCESS_HISTORY.OBJECTS_MODIFIED[0]:objectName::VARCHAR,'.',-1) as table_name
,1 as flag
FROM SNOWFLAKE.ACCOUNT_USAGE.ACCESS_HISTORY 
where 1=1
and date(QUERY_START_TIME) >= DATEADD(MONTH,-2,CURRENT_DATE())    
)
select t.table_catalog, t.table_schema, t.table_name, t.table_owner, t.table_type,t.table_owner, t.row_count, t.bytes/1024 in_mb
from snowflake.account_usage.tables t 
left join q on t.table_catalog = q.db_name and t.table_schema = q.schema_name and t.table_name = q.table_name
where t.deleted is null
and coalesce(q.flag,0) = 0
;