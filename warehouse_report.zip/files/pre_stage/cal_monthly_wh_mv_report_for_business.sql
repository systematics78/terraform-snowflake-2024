--Added calculated Credit Usage on 11th Apr 2023

with daily_credit as (
select ACCOUNT_NAME,
REGION,
SERVICE_TYPE,
date(CONVERT_TIMEZONE('UTC',START_TIME)) as START_TIME,
WAREHOUSE_NAME,
sum(CREDITS_USED_COMPUTE) as CREDITS_USED_COMPUTE,
sum(CREDITS_USED_CLOUD_SERVICES) as CREDITS_USED_CLOUD_SERVICES,
ACCOUNT_LOCATOR
from snowflake.organization_usage.warehouse_metering_history
-- where CONVERT_TIMEZONE('UTC',START_TIME) >='2023-04-11'
group by ACCOUNT_NAME,
REGION,
SERVICE_TYPE,
date(CONVERT_TIMEZONE('UTC',START_TIME)),
WAREHOUSE_NAME,
ACCOUNT_LOCATOR
)
, warehouse_metering_history as (
select ACCOUNT_NAME,
REGION,
SERVICE_TYPE,
START_TIME,
WAREHOUSE_NAME,
CREDITS_USED_COMPUTE,
CREDITS_USED_COMPUTE*.1 as PCT_10_OF_CREDITS_USED_COMPUTE,
case when PCT_10_OF_CREDITS_USED_COMPUTE > CREDITS_USED_CLOUD_SERVICES then CREDITS_USED_CLOUD_SERVICES else PCT_10_OF_CREDITS_USED_COMPUTE end as Adjustment,
CREDITS_USED_CLOUD_SERVICES,
CREDITS_USED_COMPUTE+CREDITS_USED_CLOUD_SERVICES-Adjustment as credit_usage,
ACCOUNT_LOCATOR
from daily_credit
),
q1 as (
select TO_VARCHAR(date,'YYYY-MON') as month
,case when account_name like any ('NVS2%','NVS6%') then 'Development Environment'
    when account_name like any ('NVS3%','NVS7%') then 'QA Environment'
    when account_name like any ('NVS4%','NVS8%') then 'Production Environment' end as environment
,split_part(region,'_',2)||'-'||split_part(region,'_',3) as region 
,max(effective_rate) as effective_rate
from SNOWFLAKE.ORGANIZATION_USAGE.RATE_SHEET_DAILY where service_type='COMPUTE'
group by month,account_name,region
),
q2 as (
select case when wmh.warehouse_name='CLOUD_SERVICES_ONLY' then 'F1_PLATFORM' else coalesce(q2.use_case,'Tags information not available') end as use_case
,TO_VARCHAR(start_time,'YYYY-MON') as month,wmh.warehouse_name
,case when wmh.warehouse_name='CLOUD_SERVICES_ONLY' then 'NA' else coalesce(warehouse_size,'Tags information not available') end as warehouse_size
,case when wmh.warehouse_name='CLOUD_SERVICES_ONLY' then 'NA' else coalesce(warehouse_type,'Tags information not available') end as warehouse_type
,case when wmh.warehouse_name='CLOUD_SERVICES_ONLY' then '45879' else coalesce(q2.cost_center,'Tags information not available') end as project_id
,case when wmh.warehouse_name='CLOUD_SERVICES_ONLY' then '45879' else coalesce(q2.app_id,'Tags information not available') end as app_id
,case when wmh.warehouse_name='CLOUD_SERVICES_ONLY' then 'F1_PLATFORM' else coalesce(q2.app_name,'Tags information not available') end as app_name
,case when wmh.warehouse_name='CLOUD_SERVICES_ONLY' then 'F1_PLATFORM' else coalesce(q2.domain,'Tags information not available') end as domain
-- ,round(sum(credits_used_compute),2) as credits_used
,round(sum(credit_usage),2) as Credit_Usage
,coalesce(credit_quota,500) as credits_quota
,case when wmh.warehouse_name='CLOUD_SERVICES_ONLY' then 'vasant.desai@novartis.com' else coalesce(q2.owner,'Tags information not available') end as owner
,case when wmh.warehouse_name='CLOUD_SERVICES_ONLY' then 'CONSOLIDATED' else coalesce(q2.layer,'Tags information not available') end as layer
,case when wmh.account_name like any ('NVS2%','NVS6%') then 'Development Environment'
when wmh.account_name like any ('NVS3%','NVS7%') then 'QA Environment'
when wmh.account_name like any ('NVS4%','NVS8%') then 'Production Environment' end as environment
,split_part(wmh.region,'_',2)||'-'||split_part(wmh.region,'_',3) as region
from warehouse_metering_history wmh
left join monitor_db.warehouse_monitoring.global_wh_to_uc_tags_mapping q2 on (wmh.warehouse_name = q2.warehouse_name and wmh.account_name = q2.environment and wmh.region = q2.region)
where wmh.account_name like any ('NVS2%','NVS3%','NVS4%','NVS6%','NVS7%','NVS8%')
and TO_VARCHAR(start_time,'YYYY-MON') in ('2023-Jan','2023-Feb','2023-Mar') --TO_VARCHAR(add_months(current_date(),-1),'YYYY-MM')
group by month,wmh.account_name,wmh.region,wmh.warehouse_name
,q2.use_case,q2.app_id,q2.app_name,q2.domain,q2.owner,q2.layer,q2.cost_center,warehouse_size,warehouse_type,credits_quota
union all
select coalesce(gmv.use_case,'Tags information not available') as use_case
, TO_VARCHAR(usage_date,'YYYY-MON') as month
, coalesce('Materialized_View_Maintenance - ' || use_case,'Materialized_View_Maintenance') as warehouse_name
, 'STANDARD' as WAREHOUSE_SIZE
, 'Snowflake Service' as WAREHOUSE_TYPE
,coalesce(gmv.cost_center,'Tags information not available') as project_id
,coalesce(gmv.app_id,'Tags information not available') as app_id
,coalesce(gmv.app_name,'Tags information not available') as app_name
,coalesce(gmv.domain,'Tags information not available') as domain
,round(sum(credits_used),2) as Credit_Usage
,null as credits_quota
,coalesce(gmv.owner,'Tags information not available') as owner
,coalesce(gmv.layer,'Tags information not available') as layer
,case when mv.account_name like any ('NVS2%','NVS6%') then 'Development Environment'
when mv.account_name like any ('NVS3%','NVS7%') then 'QA Environment'
when mv.account_name like any ('NVS4%','NVS8%') then 'Production Environment' end as environment
,split_part(mv.region,'_',2)||'-'||split_part(mv.region,'_',3) as region
from snowflake.organization_usage.materialized_view_refresh_history mv 
left join monitor_db.warehouse_monitoring.global_mv_to_uc_tags_mapping gmv
on (mv.database_name = gmv.database_name and mv.schema_name = gmv.schema_name and mv.table_name = gmv.materialized_view_name
    and mv.account_name = gmv.environment and mv.region = gmv.region)
where TO_VARCHAR(usage_date,'YYYY-MON') in ('2023-Jan','2023-Feb','2023-Mar') --TO_VARCHAR(add_months(current_date(),-1),'YYYY-MM')    
group by use_case,month,warehouse_name, project_id,app_id,app_name,domain,owner,layer,mv.account_name,mv.region
)
select USE_CASE,
q2.MONTH,
WAREHOUSE_NAME,
WAREHOUSE_SIZE,
WAREHOUSE_TYPE,
PROJECT_ID,
APP_ID,
APP_NAME,
DOMAIN,
Credit_Usage*effective_rate as "Cost (USD)",
Credit_Usage,
CREDITS_QUOTA,
OWNER,
LAYER,
q2.ENVIRONMENT,
q2.REGION
from q1 
join q2 on q1.region = q2. region and q1.environment = q2.environment and q1.month = q2.month
;

/*
--final warehosue mv credit report for business with new table
with q1 as (
select TO_VARCHAR(date,'YYYY-MON') as month
,case when account_name like any ('NVS2%','NVS6%') then 'Development Environment'
    when account_name like any ('NVS3%','NVS7%') then 'QA Environment'
    when account_name like any ('NVS4%','NVS8%') then 'Production Environment' end as environment
,split_part(region,'_',2)||'-'||split_part(region,'_',3) as region 
,max(effective_rate) as effective_rate
from SNOWFLAKE.ORGANIZATION_USAGE.RATE_SHEET_DAILY where service_type='COMPUTE'
group by month,account_name,region
),
q2 as (
select coalesce(q2.use_case,'Tags information not available') as use_case
,TO_VARCHAR(start_time,'YYYY-MON') as month,wmh.warehouse_name
,coalesce(warehouse_size,'Tags information not available') as warehouse_size
,coalesce(warehouse_type,'Tags information not available') as warehouse_type
,coalesce(q2.cost_center,'Tags information not available') as project_id
,coalesce(q2.app_id,'Tags information not available') as app_id
,coalesce(q2.app_name,'Tags information not available') as app_name
,coalesce(q2.domain,'Tags information not available') as domain
,round(sum(credits_used_compute),2) as credits_used
,round(sum(credits_used_compute),2) as Credit_Usage
,coalesce(credit_quota,500) as credits_quota
,coalesce(q2.owner,'Tags information not available') as owner
,coalesce(q2.layer,'Tags information not available') as layer
,case when wmh.account_name like any ('NVS2%','NVS6%') then 'Development Environment'
when wmh.account_name like any ('NVS3%','NVS7%') then 'QA Environment'
when wmh.account_name like any ('NVS4%','NVS8%') then 'Production Environment' end as environment
,split_part(wmh.region,'_',2)||'-'||split_part(wmh.region,'_',3) as region
from snowflake.organization_usage.warehouse_metering_history wmh
left join monitor_db.warehouse_monitoring.global_wh_to_uc_tags_mapping q2 on (wmh.warehouse_name = q2.warehouse_name and wmh.account_name = q2.environment and wmh.region = q2.region)
where wmh.account_name like any ('NVS2%','NVS3%','NVS4%','NVS6%','NVS7%','NVS8%')
and TO_VARCHAR(start_time,'YYYY-MON') in ('2023-Jan','2023-Feb','2023-Mar') --TO_VARCHAR(add_months(current_date(),-1),'YYYY-MM')
group by month,wmh.account_name,wmh.region,wmh.warehouse_name
,q2.use_case,q2.app_id,q2.app_name,q2.domain,q2.owner,q2.layer,q2.cost_center,warehouse_size,warehouse_type,credits_quota
union all
select coalesce(gmv.use_case,'Tags information not available') as use_case
, TO_VARCHAR(usage_date,'YYYY-MON') as month
, coalesce('Materialized_View_Maintenance - ' || use_case,'Materialized_View_Maintenance') as warehouse_name
, 'STANDARD' as WAREHOUSE_SIZE
, 'Snowflake Service' as WAREHOUSE_TYPE
,coalesce(gmv.cost_center,'Tags information not available') as project_id
,coalesce(gmv.app_id,'Tags information not available') as app_id
,coalesce(gmv.app_name,'Tags information not available') as app_name
,coalesce(gmv.domain,'Tags information not available') as domain
,round(sum(credits_used),2) as credits_used
,round(sum(credits_used),2) as Credit_Usage
,null as credits_quota
,coalesce(gmv.owner,'Tags information not available') as owner
,coalesce(gmv.layer,'Tags information not available') as layer
,case when mv.account_name like any ('NVS2%','NVS6%') then 'Development Environment'
when mv.account_name like any ('NVS3%','NVS7%') then 'QA Environment'
when mv.account_name like any ('NVS4%','NVS8%') then 'Production Environment' end as environment
,split_part(mv.region,'_',2)||'-'||split_part(mv.region,'_',3) as region
from snowflake.organization_usage.materialized_view_refresh_history mv 
left join monitor_db.warehouse_monitoring.global_mv_to_uc_tags_mapping gmv
on (mv.database_name = gmv.database_name and mv.schema_name = gmv.schema_name and mv.table_name = gmv.materialized_view_name
    and mv.account_name = gmv.environment and mv.region = gmv.region)
where TO_VARCHAR(usage_date,'YYYY-MON') in ('2023-Jan','2023-Feb','2023-Mar') --TO_VARCHAR(add_months(current_date(),-1),'YYYY-MM')    
group by use_case,month,warehouse_name, project_id,app_id,app_name,domain,owner,layer,mv.account_name,mv.region
)
select USE_CASE,
q2.MONTH,
WAREHOUSE_NAME,
WAREHOUSE_SIZE,
WAREHOUSE_TYPE,
PROJECT_ID,
APP_ID,
APP_NAME,
DOMAIN,
credits_used*effective_rate as "Cost (USD)",
Credit_Usage,
CREDITS_QUOTA,
OWNER,
LAYER,
q2.ENVIRONMENT,
q2.REGION
from q1 
join q2 on q1.region = q2. region and q1.environment = q2.environment and q1.month = q2.month
;
*/

/*
with q1 as (
select TO_VARCHAR(date,'YYYY-MON') as month
,case when account_name like any ('NVS2%','NVS6%') then 'Development Environment'
    when account_name like any ('NVS3%','NVS7%') then 'QA Environment'
    when account_name like any ('NVS4%','NVS8%') then 'Production Environment' end as environment
,split_part(region,'_',2)||'-'||split_part(region,'_',3) as region 
,max(effective_rate) as effective_rate
from SNOWFLAKE.ORGANIZATION_USAGE.RATE_SHEET_DAILY where service_type='COMPUTE'
group by month,account_name,region
),
q2 as (
select coalesce(q2.use_case,'Tags information not available') as use_case
,TO_VARCHAR(start_time,'YYYY-MON') as month,wmh.warehouse_name
,coalesce(warehouse_size,'Tags information not available') as warehouse_size
,coalesce(warehouse_type,'Tags information not available') as warehouse_type
,coalesce(q2.cost_center,'Tags information not available') as project_id
,coalesce(q2.app_id,'Tags information not available') as app_id
,coalesce(q2.app_name,'Tags information not available') as app_name
,coalesce(q2.domain,'Tags information not available') as domain
,round(sum(credits_used),2) as credits_used
,round(sum(credits_used),2) as Credit_Usage
,coalesce(credits_quota,500) as credits_quota
,coalesce(q2.owner,'Tags information not available') as owner
,coalesce(q2.layer,'Tags information not available') as layer
,case when wmh.account_name like any ('NVS2%','NVS6%') then 'Development Environment'
when wmh.account_name like any ('NVS3%','NVS7%') then 'QA Environment'
when wmh.account_name like any ('NVS4%','NVS8%') then 'Production Environment' end as environment
,split_part(wmh.region,'_',2)||'-'||split_part(wmh.region,'_',3) as region
,round(sum(credits_used_compute),2) as credits_used_compute,round(sum(credits_used_cloud_services),2) as credits_used_cloud_services
from snowflake.organization_usage.warehouse_metering_history wmh
left join control_db.utility.global_wh_to_uc_tags_mapping_table q2 on (wmh.warehouse_name = q2.warehouse_name and wmh.account_name = q2.environment and wmh.region = q2.region)
where wmh.account_name like any ('NVS2%','NVS3%','NVS4%','NVS6%','NVS7%','NVS8%')
and TO_VARCHAR(start_time,'YYYY-MM')=TO_VARCHAR(add_months(current_date(),-1),'YYYY-MM')
group by month,wmh.account_name,wmh.region,wmh.warehouse_name
,q2.use_case,q2.app_id,q2.app_name,q2.domain,q2.owner,q2.layer,q2.cost_center,warehouse_size,warehouse_type,credits_quota
union all
select coalesce(gmv.use_case,'Tags information not available') as use_case
, TO_VARCHAR(usage_date,'YYYY-MON') as month
, coalesce('Materialized_View_Maintenance - ' || use_case,'Materialized_View_Maintenance') as warehouse_name
, 'STANDARD' as WAREHOUSE_SIZE
, 'Snowflake Service' as WAREHOUSE_TYPE
,coalesce(gmv.cost_center,'Tags information not available') as project_id
,coalesce(gmv.app_id,'Tags information not available') as app_id
,coalesce(gmv.app_name,'Tags information not available') as app_name
,coalesce(gmv.domain,'Tags information not available') as domain
,round(sum(credits_used),2) as credits_used
,round(sum(credits_used),2) as Credit_Usage
,null as credits_quota
,coalesce(gmv.owner,'Tags information not available') as owner
,coalesce(gmv.layer,'Tags information not available') as layer
,case when mv.account_name like any ('NVS2%','NVS6%') then 'Development Environment'
when mv.account_name like any ('NVS3%','NVS7%') then 'QA Environment'
when mv.account_name like any ('NVS4%','NVS8%') then 'Production Environment' end as environment
,split_part(mv.region,'_',2)||'-'||split_part(mv.region,'_',3) as region
,0 as credits_used_compute,0 as credits_used_cloud_services 
from snowflake.organization_usage.materialized_view_refresh_history mv 
left join control_db.utility.global_mv_to_uc_tags_mapping_table gmv
on (mv.database_name = gmv.database_name and mv.schema_name = gmv.schema_name and mv.table_name = gmv.materialized_view_name
    and mv.account_name = gmv.environment and mv.region = gmv.region)
where TO_VARCHAR(usage_date,'YYYY-MM')=TO_VARCHAR(add_months(current_date(),-1),'YYYY-MM')    
group by use_case,month,warehouse_name, project_id,app_id,app_name,domain,owner,layer,mv.account_name,mv.region
)
select USE_CASE,
q2.MONTH,
WAREHOUSE_NAME,
WAREHOUSE_SIZE,
WAREHOUSE_TYPE,
PROJECT_ID,
APP_ID,
APP_NAME,
DOMAIN,
credits_used*effective_rate as "Cost (USD)",
Credit_Usage,
CREDITS_QUOTA,
OWNER,
LAYER,
q2.ENVIRONMENT,
q2.REGION --CREDITS_USED_COMPUTE,CREDITS_USED_CLOUD_SERVICES
from q1 
join q2 on q1.region = q2. region and q1.environment = q2.environment and q1.month = q2.month
;
*/

--Loading data into Global WH table:
--Export the data from all 6 env and load into global table
-- insert into control_db.utility.global_wh_to_uc_tags_mapping_table
select distinct WAREHOUSE_NAME,
WAREHOUSE_SIZE,
WAREHOUSE_TYPE,
APP_ID,
APP_NAME,
COST_CENTER,
DOMAIN,
LAYER,
OWNER,
SUBJECT_AREA,
USE_CASE,
current_account() as ENVIRONMENT,
current_region() as REGION,
DESCRIPTION,
CREDIT_QUOTA
from MONITOR_DB.WAREHOUSE_MONITORING.WAREHOUSE_CONSUMPTION;

--Loading data into Global MV table:
--insert into control_db.utility.global_mv_to_uc_tags_mapping_table
select distinct m.table_name as materialized_view_name,m.database_name,m.schema_name
, r.app_id, r.app_name,r.cost_center,'NA' as domain,r.layer,r.owner,r.subject_area, r.use_case,current_account() as environment,current_region() as region
,'IN ORDER TO PREVENT MATERIALIZED VIEWS FROM BECOMING OUT-OF-DATE, SNOWFLAKE PERFORMS AUTOMATIC BACKGROUND MAINTENANCE OF MATERIALIZED VIEWS.' DESCRIPTION
from SNOWFLAKE.ACCOUNT_USAGE.MATERIALIZED_VIEW_REFRESH_HISTORY m
inner join SNOWFLAKE.ACCOUNT_USAGE.TABLES t on m.database_name||'.'||m.schema_name||'.'||m.table_name = t.table_catalog||'.'||t.table_schema||'.'||t.table_name
inner join CONTROL_DB.UTILITY.ROLE_TO_UC_TAGS_MAPPING_TABLE r on r.role_name = t.table_owner
where TABLE_OWNER IS NOT NULL 
and t.deleted is null
and m.start_time > dateadd('month',-6,current_timestamp())
and m.table_name not in (select split_part(object_name,'.',-1) as materialized_view_name 
from control_db.utility.object_to_uc_tags_mapping_table);
union all;
select split_part(OBJECT_NAME,'.',-1) as materialized_view_name,
split_part(OBJECT_NAME,'.',1) as database_name,
split_part(OBJECT_NAME,'.',2) as schema_name,
APP_ID,
APP_NAME,
COST_CENTER,
'NA' domain,
LAYER,
OWNER,
SUBJECT_AREA,
USE_CASE,
current_account() as environment,
current_region() as region,
DESCRIPTION
from control_db.utility.object_to_uc_tags_mapping_table ;