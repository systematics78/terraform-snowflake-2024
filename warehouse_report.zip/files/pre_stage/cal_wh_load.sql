select warehouse_name, date(date_trunc(month,start_time)) as month
, sum(avg_running) as total_avg_running
, count(start_time) as total_count
, sum(avg_running) / count(start_time) * 100 as "Effectiveness_%age"
, sum(avg_queued_load) as total_avg_queued_load
, sum(avg_queued_load) / count(start_time) * 100 as wh_queued_load_pct
, sum(avg_queued_provisioning) as total_avg_queued_provisioning
, sum(avg_queued_provisioning) / count(start_time) * 100 as wh_queued_provisioning_pct
, sum(avg_blocked) as total_avg_blocked
, sum(avg_blocked) / count(start_time) * 100 as wh_blocked_pct
from snowflake.account_usage.warehouse_load_history
where warehouse_name in ('COM_US_ONC_DROID_DP_WH1','COM_US_ONC_FIDO_DI_WH1','COM_US_ONC_DROID_DI_WH2')
and date(start_time) >= '2022-09-01'
group by warehouse_name,month
order by month, warehouse_name;