with q1 as (
select object_name as warehouse_name,tag_name, tag_value 
from snowflake.account_usage.tag_references where domain='ROLE' and object_deleted is null
)
,q2 as (
SELECT *
FROM q1
PIVOT(max(tag_value) FOR tag_name IN ('APP_ID','APP_NAME','COST_CENTER','LAYER','OWNER','SUBJECT_AREA','USE_CASE' ,'DESCRIPTION'))
AS p (role_name, APP_ID,APP_NAME,COST_CENTER,LAYER,OWNER,SUBJECT_AREA,USE_CASE,DESCRIPTION)
ORDER BY role_name)
select q2.role_name,
q2.APP_ID,
q2.APP_NAME,
q2.COST_CENTER,
q2.LAYER,
q2.OWNER,
q2.SUBJECT_AREA,
q2.USE_CASE,
q2.DESCRIPTION    
from q2 ;