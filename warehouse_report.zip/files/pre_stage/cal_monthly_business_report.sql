--Warehouse
with q1 as (
select TO_VARCHAR(date,'YYYY-MON') as month
,case when account_name like any ('NVS2%','NVS6%') then 'Development Environment'
    when account_name like any ('NVS3%','NVS7%') then 'QA Environment'
    when account_name like any ('NVS4%','NVS8%') then 'Production Environment' end as environment
,split_part(region,'_',2)||'-'||split_part(region,'_',3) as region 
,max(effective_rate) as effective_rate
from SNOWFLAKE.ORGANIZATION_USAGE.RATE_SHEET_DAILY where service_type='COMPUTE'
group by month,account_name,region having environment is not null
)
, q2 as (
select g.USE_CASE
,TO_VARCHAR(o.START_TIME,'YYYY-MON') as month 
,g.WAREHOUSE_NAME
,g.WAREHOUSE_SIZE
,g.WAREHOUSE_TYPE
,g.cost_center as project_id
,g.APP_ID
,g.APP_NAME
,g.DOMAIN
,round(sum(o.CREDITS_USED),2) as credit_usage
,max(g.CREDIT_QUOTA) as credit_quota
,g.OWNER
,g.LAYER
,case when g.environment like any ('NVS2%','NVS6%') then 'Development Environment'
    when g.environment like any ('NVS3%','NVS7%') then 'QA Environment'
    when g.environment like any ('NVS4%','NVS8%') then 'Production Environment' end as ENVIRONMENT
,case when g.REGION ilike '%US_EAST%' then 'US-EAST'
      when g.REGION ilike '%EU_WEST%' then 'EU-WEST'
end as region1
from monitor_db.warehouse_monitoring.global_wh_to_uc_tags_mapping g
join snowflake.organization_usage.warehouse_metering_history o
    on g.warehouse_name = o.warehouse_name
    and g.region = o.region
    and g.environment = o.account_name
group by g.USE_CASE
,TO_VARCHAR(o.START_TIME,'YYYY-MON')
,g.WAREHOUSE_NAME
,g.WAREHOUSE_SIZE
,g.WAREHOUSE_TYPE
,g.cost_center
,g.APP_ID
,g.APP_NAME
,g.DOMAIN
,g.OWNER
,g.LAYER
,g.ENVIRONMENT
,region1
)
select
q2.USE_CASE
,q2.month 
,q2.WAREHOUSE_NAME
,q2.WAREHOUSE_SIZE
,q2.WAREHOUSE_TYPE
,q2.project_id
,q2.APP_ID
,q2.APP_NAME
,q2.DOMAIN
,q2.credit_usage*q1.effective_rate as "Cost(USD)"
,q2.credit_usage
,q2.credit_quota
,q2.OWNER
,q2.LAYER
,q2.ENVIRONMENT
,q1.REGION
from q2 join q1 on q2.month=q1.month and q2.environment=q1.environment and q2.region1=q1.region
where q2.month = '2023-Feb'
;

--Materialized View
select o.ORGANIZATION_NAME
,g.ENVIRONMENT
,g.REGION
,o.USAGE_DATE
,g.MATERIALIZED_VIEW_NAME
,g.DATABASE_NAME
,g.SCHEMA_NAME
,g.APP_ID
,g.APP_NAME
,g.COST_CENTER
,g.DOMAIN
,g.LAYER
,g.SUBJECT_AREA
,g.USE_CASE
,o.CREDITS_USED
,g.OWNER
,g.DESCRIPTION 
from monitor_db.warehouse_monitoring.global_mv_to_uc_tags_mapping g
join snowflake.organization_usage.materialized_view_refresh_history o
    on g.database_name = o.database_name
    and g.schema_name = o.schema_name
    and g.materialized_view_name = o.table_name
where date(usage_date) between '2023-03-01' and '2023-03-31';