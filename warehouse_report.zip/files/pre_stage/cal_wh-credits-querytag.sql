--Query to find credits wrt WH User and Role
with warehouse_spend AS
    (SELECT to_varchar(start_time,'YYYY-MM') as month, warehouse_name,Sum(total_elapsed_time) total_elapsed
    FROM "SNOWFLAKE"."ACCOUNT_USAGE"."QUERY_HISTORY"
    WHERE start_time >= Date_trunc(month, CURRENT_DATE()) and warehouse_name= 'COM_US_PHARMA_AWB_WH_SM'
    GROUP BY month, warehouse_name)
,user_spend AS
    (
    SELECT to_varchar(start_time,'YYYY-MM') as month, Sum(total_elapsed_time) total_elapsed, warehouse_name, query_tag
    FROM "SNOWFLAKE"."ACCOUNT_USAGE"."QUERY_HISTORY"
    WHERE start_time >= Date_trunc(month, CURRENT_DATE()) and warehouse_name= 'COM_US_PHARMA_AWB_WH_SM'
    GROUP BY month, warehouse_name, query_tag) 
,credits_used AS
    (
    SELECT to_varchar(start_time,'YYYY-MM') as month, Sum(credits_used) credits_used, warehouse_name
    FROM "SNOWFLAKE"."ACCOUNT_USAGE"."WAREHOUSE_METERING_HISTORY"
    WHERE start_time >= Date_trunc(month, CURRENT_DATE()) and warehouse_name= 'COM_US_PHARMA_AWB_WH_SM'
    GROUP BY month, warehouse_name)
SELECT user_spend.month, user_spend.warehouse_name, wm.warehouse_size,
user_spend.query_tag,
round((user_spend.total_elapsed / warehouse_spend.total_elapsed ) * credits_used.credits_used,2) AS credits_by_tags
, t.use_case , t.owner
FROM credits_used
JOIN user_spend ON user_spend.warehouse_name = credits_used.warehouse_name and user_spend.month = credits_used.month
JOIN warehouse_spend ON warehouse_spend.warehouse_name = credits_used.warehouse_name
left join monitor_db.warehouse_monitoring.warehouse_monitoring as wm on warehouse_spend.warehouse_name = wm.warehouse_name
left join control_db.utility.wh_to_uc_tags_mapping_table as t on warehouse_spend.warehouse_name = t.warehouse_name
where user_spend.WAREHOUSE_NAME in ('COM_US_PHARMA_AWB_WH_SM',
'COM_US_PHARMA_CON_WH2',
'COM_US_PHARMA_CON_WH1',
'COM_US_PHARMA_DI_WH2',
'COM_US_PHARMA_PSS_WH1',
'COM_US_PHARMA_AWB_WH_L',
'COM_US_PHARMA_DP_WH_3X',
'SNOWPARK_TESTING',
'COM_US_PHARMA_AWB_WH_2XL',
'COM_US_PHARMA_IP_WH1',
'COM_US_PHARMA_DQ_WH1',
'COREPL_AURA_WH_L',
'ARD_COREPL_MIGRATION_DEDICATED_WH_2X',
'COREPL_PORT_INNOV_WH_L',
'COM_US_PHARMA_DP_WH1',
'COM_US_PHARMA_NGE_WH_SM',
'COREPL_AURA_WH_M',
'COREPL_PORTFOLIO_SIZING_WH1')
order by 5 desc;