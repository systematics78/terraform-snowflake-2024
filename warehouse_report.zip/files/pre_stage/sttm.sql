CREATE OR REPLACE PROCEDURE MONITOR_DB.PUBLIC.STTM_EXPORT_METADATA()
RETURNS VARCHAR(16777216)
LANGUAGE JAVASCRIPT
EXECUTE AS OWNER
AS '
    var my_sql_command = "create or replace table MONITOR_DB.PUBLIC.STTM_METADATA as "
    my_sql_command += "select TABLE_CATALOG as DATABASE_NAME,TABLE_SCHEMA as SCHEMA_NAME, TABLE_NAME as OBJECT_NAME,COLUMN_NAME,DATA_TYPE "
    my_sql_command += "from SNOWFLAKE.ACCOUNT_USAGE.COLUMNS "
    my_sql_command += "where TABLE_CATALOG <> ''SNOWFLAKE'' and TABLE_CATALOG <> ''DEMO_DB'' and TABLE_CATALOG <> ''CURATED_RAW'' and TABLE_CATALOG <> ''MONITOR_DB'' and TABLE_CATALOG <> ''PUBLISH_DB'' and TABLE_CATALOG <> ''TEST_TEAM_DBSF'' and DELETED is null;"
    
    var my_sql_command_2 = "copy into @sttm_portal_stage/snowflake_catalog_eu.csv from (SELECT ''DATABASE_NAME'' as DATABASE_NAME, ''SCHEMA_NAME'' as SCHEMA_NAME ,''OBJECT_NAME'' as OBJECT_NAME ,''COLUMN_NAME'' as COLUMN_NAME,''DATA_TYPE'' as DATA_TYPE Union select * from MONITOR_DB.PUBLIC.STTM_METADATA) FILE_FORMAT=(format_name=CSV compression=''none'') OVERWRITE=TRUE single=true max_file_size=4900000000;"
    
    statement1 = snowflake.createStatement( {sqlText: my_sql_command} );
    var result_set1 = statement1.execute();
    
    statement2 = snowflake.createStatement({sqlText: my_sql_command_2});
    var result_set2 = statement2.execute();

  return result_set2; // Statement returned for info/debug purposes
  ';